# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class JinrongprodcutItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    prd_Sname = scrapy.Field() #产品名字
    state = scrapy.Field()
    bank_Name = scrapy.Field()  #银行名字
    entr_Curncy_Name = scrapy.Field()  #币种
    sell_Org_Date = scrapy.Field() #卖的开始日期
    sell_End_Date = scrapy.Field()  #卖的结束日期

    end_Date = scrapy.Field()  #产品收益结束日期
    entr_Min_Curncy = scrapy.Field()  #最小购买金额
    inc_Score = scrapy.Field()  #收益评级
    liq_Score = scrapy.Field() #流动性评级
    rist_Score = scrapy.Field() #风险评级
    prd_Type = scrapy.Field() #产品类型

    days = scrapy.Field()  #天数
    prd_Max_Yld_De = scrapy.Field() #收益率
    mat_Actu_Yld = scrapy.Field()
    multiple = scrapy.Field()  #与同期存储比
    star = scrapy.Field()  #综合评级
    
