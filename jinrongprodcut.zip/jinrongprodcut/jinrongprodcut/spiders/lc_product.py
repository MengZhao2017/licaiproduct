# -*- coding: utf-8 -*-
from scrapy import Spider, Request
from scrapy.selector import Selector
import requests
import re
from lxml import etree
import json
import re
import time
from  jinrongprodcut.items import  JinrongprodcutItem
import conf

#import mainGUI
#from jinrongprodcut.run import urllianjie

class licaiSpider(Spider):
    name = 'lcp'
    op = 0
   # name_mnnn=''
    custom_settings = {'ITEM_PIPELINES': {
        'jinrongprodcut.pipelines.JinrongprodcutPipeline': 300,
    }, 'DOWNLOAD_DELAY': 0.1,'DOWNLOAD_TIMEOUT':20}


   
    def start_requests(self):
        url = 'http://bank.jrj.com.cn/bankpro/data.shtml'
        # urllianjie=url_input.get()
        # print(urllianjie)  
        req = Request(url,
                      self.parse_max_page, dont_filter=True)
        # req = Request(url,
                    #   self.parse_max_page, dont_filter=True,meta={'lj': urllianjie})
        yield req


  

    def parse_max_page(self, response):
        #lljj = response.meta['lj']
        
        #print(pagecount)
        urlr = 'http://bankpro.jrj.com.cn/json/f.jspa?size=20&pn={}'

        

        print ('')
        print ('')
        print('*****************************************请选择下列想要获取数据的银行(回车键结束)****************************************')
        print('                                 1  ------>  BOC      |     9   ------>  suzhou  ')  
        print('                                 2  ------>  CMB      |     10  ------>  pufa  ')
        print('                                 3  ------>  CCB      |     11  ------>  zhongxin  ')
        print('                                 4  ------>  BCM      |     12  ------>  guangda  ')
        print('                                 5  ------>  ICBC     |     13  ------>  minsheng  ')
        print('                                 6  ------>  ABC      |     14  ------>  pinan  ')
        print('                                 7  ------>  5-ALL    |     15  ------>  huifeng  ')
        print('                                 8  ------>  all—ALL  |     16  ------>  mer-all  ')
        print ('')

        canshu=input(' 请输入上方的数字序号:  ')
        cs=''
        if(canshu=='1'):
            cs=conf.lj_zhonghang
            name_mn='BOC'
        elif canshu=='2':
            cs=conf.lj_CMB
            name_mn='CMB'
        elif canshu=='3':
            cs=conf.lj_jianshe
            name_mn='CCB'
        elif canshu=='4':
            cs=conf.lj_jiaotong
            name_mn='BCM'
        elif canshu=='5':
            cs=conf.lj_gongshang
            name_mn='ICBC'
        elif canshu=='6':
            cs=conf.lj_nongye
            name_mn='ABC'
        elif canshu=='7':
            cs=conf.lj_all_wuda
            name_mn='ALL'
        elif canshu=='8':
            cs=conf.lj_all
        elif canshu=='9':
            cs=conf.lj_suzhou
        elif canshu=='10':
            cs=conf.lj_pufa
        elif canshu=='11':
            cs=conf.lj_zhongxin
        elif canshu=='12':
            cs=conf.lj_guangda
        elif canshu=='13':
            cs=conf.lj_minsheng
        elif canshu=='14':
            cs=conf.lj_pingan
        elif canshu=='15':
            cs=conf.lj_huifeng
        elif canshu=='16':
            cs=conf.lj_all_mer
        else:
            print('您输入有误，请确认是否正确输入上述数字！')
       # canshu = '&t={}'  #%22st%22:%220%22,%22xsdq%22:%22-1,-1%22,%22sort%22:%22sell_org_date%22,%22order%22:%22desc%22,%22wd%22:%22%22
        print('')
        print('')
        print('*****************************************请输入您想要获得数据的页码数(回车键结束)****************************************')
        print('')
        pgg=input('please input your page:  ')
        
        pagecount=0
        if(pgg==''):
            print('您输入的为空，请重新输入!')
            pgg=input('please input your page:')
        elif(pgg.isdigit()==True):
            pagecount = int(pgg) #35132
        else:
            print('请输入正确的页码数')
            pgg=input('please input your page:  ')
        
        for page in range(1, pagecount):
            if page<pagecount:
                print(page)
                yield Request(urlr.format(
                    page) + '&t='+cs,
                              self.dual_list, dont_filter=True)
            else:
                break

    def dual_list(self, response):
        if response.status == 200:
            ss='http://1.1.1.3:89/cookie/flashcookie.swf'
            if response.body.find(ss.encode())!=-1:
                yield Request(response.url, self.dual_list, dont_filter=True)
            else:
                #print(response.body)
                
                body = json.loads(re.findall('var bps=(.*)', str(response.body,'utf-8'))[0])['bankProductList']
                for cc in body:
                    item = JinrongprodcutItem()
                    if(cc['prd_Sname']==''):
                        item['prd_Sname']='null'
                    else:
                        item['prd_Sname'] = cc['prd_Sname']
                    
                    if(cc['state']== -1):
                        item['state']='null'
                    elif(cc['state']==1):
                        item['state'] = '预售'
                    elif cc['state']==0:
                        item['state'] = '现售'
                    elif cc['state']==2:
                        item['state'] = '停售'
                    else:
                        item['state'] = '未知'
                    
                    if cc['bank_Name']=='':
                        item['bank_Name']='null'
                    else:
                        item['bank_Name'] = cc['bank_Name']
                    if(cc['entr_Curncy_Name']==''):
                        item['entr_Curncy_Name']='null'
                    else:
                        item['entr_Curncy_Name'] = cc['entr_Curncy_Name']
                    if(cc['sell_Org_Date']==''):
                        item['sell_Org_Date']='null'
                    else:
                        item['sell_Org_Date'] = cc['sell_Org_Date']
                    if(cc['sell_End_Date']==''):
                        item['sell_End_Date']='null'
                    else:
                        item['sell_End_Date'] = cc['sell_End_Date']
                    if(cc['end_Date']==''):
                        item['end_Date']='null'
                    else:
                        item['end_Date'] = cc['end_Date']
                    if(cc['entr_Min_Curncy']==''):
                        item['entr_Min_Curncy']='null'
                    else:
                        item['entr_Min_Curncy'] = cc['entr_Min_Curncy']
                    if(cc['inc_Score']==''):
                        item['inc_Score']='null'
                    else:
                        item['inc_Score'] = cc['inc_Score']
                    if(cc['liq_Score']==''):
                        item['liq_Score']='null'
                    else:
                        item['liq_Score'] = cc['liq_Score']
                    if(cc['rist_Score']==''):
                        item['rist_Score']='null'
                    else:
                        item['rist_Score'] = cc['rist_Score']
                    #item['prd_Type'] = cc['prd_Type']

                    if(cc['prd_Type']=='5'):
                        item['prd_Type'] = '保本浮动收益'
                    elif cc['prd_Type']=='6':
                        item['prd_Type'] = '非保本浮动收益'
                    elif cc['prd_Type']=='3':
                        item['prd_Type'] = '保本固定收益'
                    else:
                        item['prd_Type'] = cc['prd_Type']
                    if(cc['days']==''):
                        item['days']='null'
                    else:
                        item['days'] = cc['days']+'天'

                    if cc['prd_Max_Yld_De']=='':
                        item['prd_Max_Yld_De'] ='null'
                    else:
                        item['prd_Max_Yld_De'] = cc['prd_Max_Yld_De']+'%'

                    if(cc['mat_Actu_Yld']==''):
                        item['mat_Actu_Yld']='null'
                    else:
                        item['mat_Actu_Yld'] = cc['mat_Actu_Yld']
                    if(cc['multiple']==''):
                        item['multiple']='null'
                    else:
                        item['multiple'] = cc['multiple']+'倍'
                    if(cc['star']==''):
                        item['star']='null'
                    else:
                        item['star'] = cc['star']
                    yield item

        else:
            yield Request(response.url, self.dual_list, dont_filter=True)

