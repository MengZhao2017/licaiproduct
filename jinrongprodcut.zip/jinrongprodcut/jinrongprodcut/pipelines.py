# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import sys
import os
import csv
#import pymysql   #连接mysql
#import pymssql   #连接sql server

class JinrongprodcutPipeline(object):
    def __init__(self):
        # csv文件的位置,无需事先创建
        print('*****************************************请输入您想要保存的文件名(回车键结束)****************************************')
        print('')
        name_mm=input('请输入要保存文件的名字：  ')
        store_file = os.path.dirname(__file__) + '__' +name_mm+'.csv'
        # 打开(创建)文件
        self.file = open(store_file, 'w',encoding='gb18030')
        # csv写法
        self.writer = csv.writer(self.file)
        self.writer.writerow(('产品名称', '发行状态','发行银行', '委托货币', '发行日期', '停售日期', '管理期(天)', '预期收益率(%)', '到期收益率(%)', '与同期储蓄比(%)', '综合评级(10)','收益结束日期','最小购买金额(元)','收益性评级(100)','流动性评级(100)','安全性评级(100)','收益类型'))
        
        #连接mysql

        #self.connect=pymysql.connect(host='localhost',user='root',password='123456',db='licai',port=8888)
        #self.cursor=self.connect.cursor()  


    def process_item(self, item, spider):
        
        self.writer.writerow((item['prd_Sname'], item['state'],item['bank_Name'], item['entr_Curncy_Name'],item['sell_Org_Date'], item['sell_End_Date'],item['days'], item['prd_Max_Yld_De'], item['mat_Actu_Yld'], item['multiple'],item['star'],item['end_Date'],item['entr_Min_Curncy'],item['inc_Score'],item['liq_Score'],item['rist_Score'],item['prd_Type']))
        
        #往数据库里写数据
        #self.cursor.execute('insert into licaiTable(prd_Sname,state,bank_Name,entr_Curncy_Name,sell_Org_Date,sell_End_Date,days,prd_Max_Yld_De,mat_Actu_Yld,multiple,star,end_Date,entr_Min_Curncy,inc_Score,liq_Score,rist_Score,prd_Type) VALUES ("{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}","{}")'.format(item['prd_Sname'], item['state'], item['bank_Name'], item['entr_Curncy_Name'],item['sell_Org_Date'], item['sell_End_Date'],item['days'], item['prd_Max_Yld_De'], item['mat_Actu_Yld'], item['multiple'],item['star'],item['end_Date'],item['entr_Min_Curncy'],item['inc_Score'],item['liq_Score'],item['rist_Score'],item['prd_Type']))
        #self.connect.commit()

        return item

    def close_spider(self, spider):
        #关闭数据库
        #self.cursor.close()
        #self.connect.close()
        

        self.file.close()
