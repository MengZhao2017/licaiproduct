from tkinter import *

from scrapy.cmdline import execute
import sys
import os



def mian():
    global url_input,text
    global urllianjie
    root = Tk()
    root.title('BankProduct')
    root.geometry('600x300+398+279')
    Label(root,text='请输入要下载的URL：',font=("华文行楷",15),fg='black').grid()
    url_input=Entry(root,font=("微软雅黑",15),width=50)
    url_input.grid(row=0,column=1)
    text=Listbox(root,font=('微软雅黑',15),width=45,height=10)
    
    text.grid(row=1,columnspan=2)
    button =Button(root,text='开始下载',font=("微软雅黑",15),command=Crawl_content).grid(row=2,column=0,sticky=W)
    button =Button(root,text='退出',font=("微软雅黑",15),command=root.quit).grid(row=2,column=1,sticky=E)
    mainloop()


    


def Crawl_content():
    urllianjie=url_input.get()
    print(urllianjie)

  



mian()